# TPSI-MULTIMEDIA-Project
Projeto de avaliação da cadeira de Ferramentas e práticas multimédia

## Objetivo
Do projeto é pedido que resulte num website responsivo e otimizado para telemóvel com no mínimo 3 páginas HTML e CSS, com um tema à escolha e que aplique as técnicas que abordámos nas aulas.
